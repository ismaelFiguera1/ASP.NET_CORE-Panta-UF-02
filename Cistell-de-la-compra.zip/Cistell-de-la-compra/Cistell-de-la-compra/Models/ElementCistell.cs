﻿namespace Cistell_de_la_compra.Models
{
    public class ElementCistell
    {
        public string CodiProducte { get; set; }
        public int Quantitat { get; set; }
    }
}
